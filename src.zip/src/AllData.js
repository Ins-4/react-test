const AllData = [
    {
        id: 1,
        title: 'ВТБ вычел из своих активов En+',
        article: '1111Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam, quasi, quis et molestiae, illum necessitatibus aliquid nihil dicta laboriosam dolor dolore asperiores quisquam consectetur voluptatu',
        source: 'meduza.com',
        date: '09/02'
     },
    {
        id: 2,
        title: 'ВМинистерства спорят об иностранных процента',
        article: '2222Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam, quasi, quis et molestiae, illum necessitatibus aliquid nihil dicta laboriosam dolor dolore asperiores quisquam consectetur voluptatu',
        source: 'rbc.ru',
        date: '04/02'
    },
    {
        id: 3,
        title: '333В Минске раскрыли детали соглашения о покупке нефти в России',
        article: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam, quasi, quis et molestiae, illum necessitatibus aliquid nihil dicta laboriosam dolor dolore asperiores quisquam consectetur voluptatu',
        source: 'meduza.com',
        date: '09/02'
    },
    {
        id: 4,
        title: 'Пассажирский Boeing компании Utair совершил жесткую посадку в Коми',
        article: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam, quasi, quis et molestiae, illum necessitatibus aliquid nihil dicta laboriosam dolor dolore asperiores quisquam consectetur voluptatu',
        source: 'meduza.com',
        date: '09/02'
    },
    {
        id: 5,
        title: 'ВТБ вычел из своих активов En+',
        article: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam, quasi, quis et molestiae, illum necessitatibus aliquid nihil dicta laboriosam dolor dolore asperiores quisquam consectetur voluptatu',
        source: 'meduza.com',
        date: '09/02'
    },
    {
        id: 6,
        title: 'ВТБ вычел из своих активов En+',
        article: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam, quasi, quis et molestiae, illum necessitatibus aliquid nihil dicta laboriosam dolor dolore asperiores quisquam consectetur voluptatu',
        source: 'meduza.com',
        date: '09/02'
    },
    {
        id: 6,
        title: 'ВТБ вычел из своих активов En+',
        article: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam, quasi, quis et molestiae, illum necessitatibus aliquid nihil dicta laboriosam dolor dolore asperiores quisquam consectetur voluptatu',
        source: 'meduza.com',
        date: '09/02'
    },
    {
        id: 6,
        title: 'ВТБ вычел из своих активов En+',
        article: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam, quasi, quis et molestiae, illum necessitatibus aliquid nihil dicta laboriosam dolor dolore asperiores quisquam consectetur voluptatu',
        source: 'meduza.com',
        date: '09/02'
    },
    {
        id: 6,
        title: 'ВТБ вычел из своих активов En+',
        article: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam, quasi, quis et molestiae, illum necessitatibus aliquid nihil dicta laboriosam dolor dolore asperiores quisquam consectetur voluptatu',
        source: 'meduza.com',
        date: '09/02'
    },

]

export default AllData;