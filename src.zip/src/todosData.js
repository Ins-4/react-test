const todosData = [
    {
        id: 1,
        text: 'Погулять с псом',
        completed: false
    },
    {
        id: 2,
        text: 'Сделать домашнюю работу',
        completed: true
    },
    {
        id: 3,
        text: 'Сходить за хлебом',
        completed: false
    },

]

export default todosData;