import React from 'react';

const Title = (props) =>{
    return(
        <h1 className = "page_title" >{props.title}</h1>
    )
}
export default Title;